/**
 * This class stores the information for an employee.
 * @author Daniel Simard
 */

public class Employee {
    private String employeeName;
    private int idNumber;
    private String department;
    private String position;
    private double payRate;
    private double hoursPerWeek;

    /**
     * A no-arg constructor that assigns empty strings ("") to the name, department, and
     * position fields and 0 to the idNumber field, the payRate field, and the hoursPerWeek field.
     */
    public Employee() {
        employeeName = "";
        idNumber = 0;
        department = "";
        position = "";
        payRate = 0;
        hoursPerWeek = 0;
    }

    /**
     * A constructor that accepts the following values as arguments and assigns them to the
     * appropriate fields: employee's name, employee's ID number, department, position, payRate and hoursPerWeek.
     * @param name the name of the employee
     * @param id the id code of the employee
     * @param dept the department the employee is in
     * @param pos the position the employee has
     * @param rate the amount paid hourly to the employee
     * @param hours amount of hours employee worked
     */
    public Employee(String name, int id, String dept, String pos, double rate, double hours) {
        employeeName = name;
        idNumber = id;
        department = dept;
        position = pos;
        payRate = rate;
        hoursPerWeek = hours;
    }

    /**
     * A constructor that accepts the following values as arguments and assigns them to the
     * appropriate fields: employee's name and ID number. The department and position fields
     * should be assigned an empty string (""). The payRate and hoursPerWeek are initialized as 0.
     * @param name the name of the employee
     * @param id the id code of the employee
     */
    public Employee(String name, int id) {
        this.employeeName = name;
        this.idNumber = id;
        this.department = "";
        this.position = "";
        this.payRate = 0;
        this.hoursPerWeek = 0;
    }

    /**
     * Sets employee name.
     * @param name the name of the employee
     */
    public void setEmployeeName(String name) {
        this.employeeName = name;
    }

    /**
     * Gets employee name.
     * @return adding employee name to parameter
     */
    public String getEmployeeName() {
        return employeeName;
    }

    /**
     * Sets ID number.
     * @param id the id code of the employee
     */
    public void setIdNumber(int id) {
        this.idNumber = id;
    }

    /**
     * Gets ID number.
     * @return adding employee id number to parameter
     */
    public int getIdNumber() {
        return idNumber;
    }

    /**
     * Sets department.
     * @param dept the department the employee is in
     */
    public void setDepartment(String dept) {
        this.department = dept;
    }

    /**
     * Gets department.
     * @return adding employee department to parameter
     */
    public String getDepartment() {
        return department;
    }

    /**
     * Sets position.
     * @param pos the position the employee has
     */
    public void setPosition(String pos) {
        this.position = pos;
    }

    /**
     * Gets position.
     * @return adding employee position to parameter
     */
    public String getPosition() {
        return position;
    }

    /**
     * Sets rate.
     * @param rate the amount paid hourly to the employee
     */
    public void setPayRate(double rate) { this.payRate = rate; }

    /**
     * Gets position.
     * @return adding employee hourly pay to the parameter
     */
    public double getPayRate() { return payRate; }

    /**
     * Sets hours.
     * @param hours amount of hours employee worked
     */
    public void setHoursPerWeek (double hours) { this.hoursPerWeek = hours; }

    /**
     * Gets hours.
     * @return adding employee hours worked to the parameter
     */
    public  double getHoursPerWeek() { return hoursPerWeek; }
}
