/**
 * This class calls the Employee class and creates a parameter.
 * @author Daniel Simard
 */

public class EmployeeTest {
    public static void main(String args[]) {
        //Demonstrating one constructor
        Employee employee1 = new Employee("Susan Meyers", 47899, "Accounting", "Vice President", 85.0, 40.0);

        //Demonstrating the second constructor and two mutators
        Employee employee2=new Employee("Mark Jones",39119);
        employee2.setDepartment("IT");
        employee2.setPosition("Programmer");
        employee2.setPayRate(50.0);
        employee2.setHoursPerWeek(60.0);

        //Demonstrating the no-arg constructor and all mutators
        Employee employee3=new Employee();
        employee3.setEmployeeName("Joy Rogers");
        employee3.setIdNumber(81774);
        employee3.setDepartment("Manufacturing");
        employee3.setPosition("Engineer");
        employee3.setPayRate(45.0);
        employee3.setHoursPerWeek(37.5);

        //Displaying employee1 information
        System.out.println("Employee 1 name: "+ employee1.getEmployeeName());
        System.out.println("Employee 1 id: "+ employee1.getIdNumber());
        System.out.println("Employee 1 department: "+ employee1.getDepartment());
        System.out.println("Employee 1 position: "+ employee1.getPosition());
        System.out.println("Employee 1 weekly: $" + (employee1.getPayRate() * employee1.getHoursPerWeek()));
        System.out.println();

        //Displaying employee2 information:
        System.out.println("Employee 2 name: "+ employee2.getEmployeeName());
        System.out.println("Employee 2 id: "+ employee2.getIdNumber());
        System.out.println("Employee 2 department: "+ employee2.getDepartment());
        System.out.println("Employee 2 position: "+ employee2.getPosition());
        System.out.println("Employee 2 weekly: $" + (employee2.getPayRate() * employee2.getHoursPerWeek()));
        System.out.println();

        //Displaying employee3 information
        System.out.println("Employee 3 name: "+ employee3.getEmployeeName());
        System.out.println("Employee 3 id: "+ employee3.getIdNumber());
        System.out.println("Employee 3 department: "+ employee3.getDepartment());
        System.out.println("Employee 3 position: "+ employee3.getPosition());
        System.out.println("Employee 3 weekly: $" + (employee3.getPayRate() * employee3.getHoursPerWeek()));
        System.out.println();
    }
}
